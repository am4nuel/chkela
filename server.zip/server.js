const express = require("express");
const http = require("http");
const cors = require("cors");
const socketIo = require("socket.io");
const db = require("./models");
const notesRouter = require("./routes/fileHandleRoute");
const quizRoutes = require("./routes/quiz");

const courseRoutes = require("./routes/courseRoutes");
const examRoutes = require("./routes/examRoutes");
const flashCardRoutes = require("./routes/flashCardRoutes");
const videoRoutes = require("./routes/videoRoutes");
const { Op } = require("sequelize");
const sequelize = require("sequelize");
const postRoutes = require("./routes/postRoutes");
const communityRoutes = require("./routes/communityRoutes");
const paymentRoutes = require("./routes/paymentRoutes");
const chatRoutes = require("./routes/chatRoutes"); // New chat route
const crypto = require("crypto");
const profileUpdate = require("./routes/profileUpdate"); // New chat route
const {
  User,
  Message,
  UserStatistics,
  Payment,
  FollowUser,
  FollowCommunity,
  Post,
  Referral,
  Community,
  Bank,
  GuideVideo,
  UserInterest,
} = require("./models");

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

app.use(cors());
app.use(express.json()); // For parsing application/json
app.use(express.urlencoded({ extended: true })); // For parsing application/x-www-form-urlencoded
app.set("io", io);
// Routes
app.use("/uploads", express.static("uploads"));
app.use("/file", notesRouter);
app.use("/quiz", quizRoutes);
app.use("/course", courseRoutes);
app.use("/exam", examRoutes);
app.use("/card", flashCardRoutes);
app.use("/video", videoRoutes);
app.use("/post", postRoutes);
app.use("/community", communityRoutes);
app.use("/payment", paymentRoutes);
app.use("/update", profileUpdate);
app.use("/chat", chatRoutes); // Use the new chat route
app.use(express.static("client/build"));

// Socket.IO setup
let clients = {}; // Dictionary to keep track of connected clients

// Function to load users into the clients list
const loadClients = async () => {
  try {
    const users = await User.findAll();
    users.forEach((user) => {
      clients[user.id] = null;
    });
    console.log("Users loaded into clients list");
  } catch (error) {
    console.error("Error loading users:", error);
  }
};

// Load users when the server starts
loadClients();

io.on("connection", (socket) => {
  const userId = socket.handshake.query.userId;

  if (userId) {
    // Register the client with userId
    clients[userId] = socket;
    console.log(`User ${userId} registered with socket ID: ${socket.id}`);
  } else {
    console.error("User ID not provided during connection");
  }

  // Handle incoming messages
  socket.on("message", async (data) => {
    const { senderId, receiverId, content } = data;
    console.log("Message received", senderId, receiverId, content);
    console.log(
      "A user connected with socket ID:",
      socket.handshake.query.userId
    );
    2;
    // Send message to the recipient if they are connected

    // Create message in the database
    if (senderId && receiverId && content) {
      try {
        await Message.create({ senderId, receiverId, content });
        console.log("Message created successfully");
        const currentTime = new Date().toISOString();
        if (clients[receiverId]) {
          clients[receiverId].emit("message", {
            senderId,
            receiverId,
            timestamp: currentTime,
            content,
            isRead: false,
          });
        } else {
          console.log("user not found", clients, receiverId);
        }
      } catch (error) {
        console.error("Error creating message:", error);
      }
    } else {
      console.error(
        "Validation failed: senderId, receiverId, and content must be provided"
      );
    }
  });
  socket.on("paymentNotice", (paymentData) => {
    console.log("Payment Notice received:", paymentData);

    // Emit the paymentNotice event to all connected clients
    io.emit("paymentNotice", paymentData);
  });
  // Handle disconnection
  socket.on("disconnect", () => {
    for (let key in clients) {
      if (clients[key] === socket) {
        clients[key] = null;
        console.log(`User disconnected`);
        break;
      }
    }
  });
});

// API Endpoints
app.post("/register", async (req, res) => {
  try {
    // Create the user
    const userData = await User.create(req.body);

    // Generate unique promo code
    const promoCode = await generateUniquePromoCode(userData);

    // Update the user with the promo code
    await User.update({ promoCode }, { where: { id: userData.id } });

    // Retrieve the user and send response
    const user = await User.findOne({ where: { id: userData.id } });
    res.status(201).send({ user });
    // Create user statistics
    await UserStatistics.create({ userId: userData.id });

    // Check for a promo code in the request
    if (req.body.promoCode) {
      await checkAndApplyPromoCode(req.body.promoCode, userData.id);
    }
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).send({ message: "Error creating user. Please try again." });
  }
});

const checkAndApplyPromoCode = async (promoCode, referredId) => {
  try {
    // Find user with the promo code
    const referringUser = await User.findOne({
      where: { promoCode },
    });

    if (referringUser) {
      // Create referral entry if promo code matches
      await Referral.create({
        referred: referredId,
        referredBy: referringUser.id,
      });
      return referringUser; // Return the referring user if found
    }
    // Find the user's statistics
    const userStats = await UserStatistics.findOne({
      where: { userId: referringUser.id },
    });

    if (!userStats) {
      return res.status(404).json({ error: "User statistics not found" });
    }
    userStats.point += 500;

    // Save the updated statistics
    await userStats.save();

    console.log("User not found with the provided promo code:", promoCode);
    return null; // No referring user found
  } catch (error) {
    console.error("Error applying promo code:", error);
    throw error;
  }
};

async function generateUniquePromoCode(user) {
  const generatePromoCode = () => {
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let nameHash = 0;

    for (let i = 0; i < user.fullName.length; i++) {
      nameHash = user.fullName.charCodeAt(i) + ((nameHash << 5) - nameHash);
    }

    let randomLetters = "";
    for (let i = 0; i < 3; i++) {
      randomLetters += letters.charAt(Math.abs(nameHash + i) % letters.length);
    }

    let phone = user.phoneNumber.replace(/\D/g, "");
    let staticDigits =
      phone.length >= 8 ? phone.substring(5, 8) : phone.substring(0, 3);

    return `${randomLetters}${staticDigits}`;
  };

  let promoCode;
  let exists = true;
  let attempts = 0;

  while (exists && attempts < 10) {
    // Set a limit on attempts
    promoCode = generatePromoCode();

    // Check if the promo code already exists in the database
    const existingPromoCode = await User.findOne({
      where: { promoCode },
    });

    exists = !!existingPromoCode; // Set exists to true if a promo code is found
    attempts++;
  }

  if (exists) {
    throw new Error(
      "Could not generate a unique promo code after multiple attempts."
    );
  }

  return promoCode;
}

app.post("/login", async (req, res) => {
  try {
    const { phoneNumber, password } = req.body;

    // Find user by phoneNumber
    const userLog = await User.findOne({ where: { phoneNumber } });

    if (!userLog) {
      return res.status(404).send("User not found.");
    }

    // Check if password is valid
    const isPasswordValid = password === userLog.password;
    if (!isPasswordValid) {
      return res.status(401).send("Invalid password.");
    }

    // Generate a random sessionId
    const sessionId = crypto.randomBytes(16).toString("hex");

    // Update the sessionId field in the database
    await User.update({ sessionId }, { where: { phoneNumber } });

    // Fetch the updated user data along with related models (Payment, UserStatistics)
    const user = await User.findOne({
      where: { phoneNumber },
      include: [Payment, UserStatistics],
    });

    // Send the updated user object as response
    res.status(200).send({ user });
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).send("An error occurred during login.");
  }
});
app.post("/check-session", async (req, res) => {
  try {
    const { userId, sessionId } = req.body;

    // Find the user by userId
    const user = await User.findOne({ where: { id: userId } });

    if (!user) {
      // User not found
      return res.status(404).send("User not found.");
    }

    // Check if the sessionId matches
    if (user.sessionId === sessionId) {
      // Session matches, user is logged in on this device
      return res
        .status(200)
        .send("Session is valid. User is logged in on this device.");
    } else {
      // Session doesn't match, user is logged in on another device
      return res
        .status(403)
        .send("Session invalid. User is logged in on another device.");
    }
  } catch (error) {
    console.error("Error during session validation:", error);
    res.status(500).send("An error occurred during session validation.");
  }
});

app.get("/messages/:userId1/:userId2", async (req, res) => {
  const { userId1, userId2 } = req.params;

  try {
    const messages = await Message.findAll({
      where: {
        [Op.or]: [
          { senderId: userId1, receiverId: userId2 },
          { senderId: userId2, receiverId: userId1 },
        ],
      },
      order: [["timestamp", "ASC"]], // Optional: to sort messages by timestamp
    });

    res.json(messages);
  } catch (error) {
    console.error("Error fetching messages:", error);
    res.status(500).json({ error: "Failed to fetch messages" });
  }
});
app.get("/users", async (req, res) => {
  try {
    const { page = 1, limit } = req.query;

    const offset = (page - 1) * limit;

    const whereClause = {};

    const users = await User.findAll({
      where: whereClause,
      include: [{ model: UserStatistics }],
    });
    console.log(users[0].promoCode);
    res.json({
      users,
    });
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
  }
});
app.get("/single-user", async (req, res) => {
  try {
    const { userId } = req.query;
    const whereClause = { userId: userId };

    const user = await User.findOne({
      where: whereClause,
      include: [{ model: UserStatistics }],
    });
    res.json({
      user,
    });
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
  }
});
app.get("/users-filter", async (req, res) => {
  try {
    const { search, page = 1, limit } = req.query;

    const offset = (page - 1) * limit;

    const whereClause = {};
    if (search) {
      whereClause[Op.or] = [
        { category: { [Op.like]: `%${search}%` } },
        { grade: { [Op.like]: `%${search}%` } },
      ];
    }

    const { rows: users, count: totalUsers } = await User.findAndCountAll({
      where: whereClause,
      offset,
      limit: Number(limit),
    });

    res.json({
      users,
      totalUsers,
      totalPages: Math.ceil(totalUsers / limit),
      currentPage: Number(page),
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Server Error" });
  }
});

app.post("/interests", async (req, res) => {
  const { userId, interests } = req.body;
  try {
    // First, clear any existing interests for the user
    await UserInterest.destroy({ where: { userId } });

    const userInterests = interests.map((interest) => ({
      userId,
      interest,
    }));

    await UserInterest.bulkCreate(userInterests);

    res.status(200).json({ message: "Interests submitted successfully" });
  } catch (error) {
    console.error("Error submitting interests:", error);
    res.status(500).json({ error: "Failed to submit interests" });
  }
});
app.post("/join", async (req, res) => {
  const { follower, followed, followedType } = req.body;
  console.log("data", follower, followed, followedType);

  try {
    let followerC;

    if (followedType === "User") {
      // Remove existing follow for users
      await FollowUser.destroy({
        where: { follower, followed },
      });
      // Create new follow for users
      followerC = await FollowUser.create({
        follower: follower,
        followed: followed,
      });
    } else if (followedType === "Community") {
      // Remove existing follow for communities
      await FollowCommunity.destroy({
        where: { follower, followed },
      });
      // Create new follow for communities
      followerC = await FollowCommunity.create({
        follower: follower,
        followed: followed,
      });
    }

    if (followerC) {
      console.log("created");
      res.status(200).send({ followerC });
    } else {
      console.log("not created");
      res.status(424).send({ followerC });
    }
  } catch (error) {
    console.log("something went wrong", error);
    res.status(500).send({ error: "An error occurred" });
  }
});

app.post("/check-following", async (req, res) => {
  const { follower, followed, type } = req.body;

  try {
    let found;

    if (type === "User") {
      found = await FollowUser.findOne({
        where: { follower, followed },
      });
    } else if (type === "Community") {
      found = await FollowCommunity.findOne({
        where: { follower, followed },
      });
    }

    if (found) {
      console.log("hit", follower, followed, type);
      res.status(200).send({ found });
    } else {
      console.log("miss", follower, followed, type);
      res.status(404).send({ message: "No following record found" });
    }
  } catch (error) {
    console.log("something went wrong", error);
    res.status(500).send({ error: "An error occurred" });
  }
});

app.post("/dismember", async (req, res) => {
  const { follower, followed, followedType } = req.body;
  console.log("data", follower, followed, followedType);

  try {
    let followerC;

    if (followedType === "User") {
      // Remove follow for users
      followerC = await FollowUser.destroy({
        where: { follower, followed },
      });
    } else if (followedType === "Community") {
      // Remove follow for communities
      followerC = await FollowCommunity.destroy({
        where: { follower, followed },
      });
    }

    if (followerC) {
      console.log("removed");
      res.status(200).send({ message: "Unfollow successful" });
    } else {
      console.log("not removed");
      res.status(404).send({ message: "No record found to unfollow" });
    }
  } catch (error) {
    console.log("something went wrong", error);
    res.status(500).send({ error: "An error occurred" });
  }
});

app.post("/count-return", async (req, res) => {
  const { userId, followedType } = req.body;

  // Validate input
  if (!userId || !followedType) {
    return res
      .status(400)
      .json({ error: "Missing required fields: userId and followedType" });
  }

  try {
    if (followedType === "User") {
      const followerCount = await FollowUser.count({
        where: { followed: userId },
      }); // Count followers based on userId and followedType

      // Count posts where userId matches the provided userId
      const postCount = await Post.count({
        where: { userId }, // Ensure this is the correct field name
      });

      // Fetch user statistics for the given userId
      const userStatistics = await UserStatistics.findOne({
        where: { userId },
      });

      // Prepare the response data
      const responseData = {
        followerCount,
        postCount,
        userStatistics: userStatistics || null,
      };
      console.log(responseData);
      res.status(200).json(responseData);
    } else {
      if (followedType === "Community") {
        console.log("back no");
        const followerCount = await FollowCommunity.count({
          where: { followed: userId },
        }); // Count followers based on userId and followedType

        // Count posts where userId matches the provided userId
        const postCount = await Post.count({
          where: { ownerType: userId }, // Ensure this is the correct field name
        });
        // Prepare the response data
        const responseData = {
          followerCount,
          postCount,
          userStatistics: null,
        };
        console.log(responseData);
        res.status(200).json(responseData);
      }
    }
  } catch (error) {
    console.error("Something went wrong:", error);
    res.status(500).json({ error: "An internal server error occurred" });
  }
});

app.post("/update-user", async (req, res) => {
  const { birthDate, profileImage, gender, id } = req.body;
  console.log(birthDate, profileImage, gender, id);
  try {
    const update = await User.update(
      { birthDate, profileImage, gender },
      {
        where: { id },
      }
    );

    if (update) {
      console.log("updated");
      res.status(200).send({ update });
    } else {
      console.log("not updated");
      res.status(424).send({ update });
    }
  } catch (error) {
    console.log("something went wrong", error);
  }
});
app.post("/manage-pts", async (req, res) => {
  const { userId, point, actionType } = req.body;

  try {
    // Find the user's statistics
    const userStats = await UserStatistics.findOne({
      where: { userId: userId },
    });

    if (!userStats) {
      return res.status(404).json({ error: "User statistics not found" });
    }

    // Perform action based on actionType
    if (actionType === "add") {
      userStats.point += point;
    } else if (actionType === "sub") {
      if (userStats.point < point) {
        return res.status(400).json({ error: "Insufficient points" });
      }
      userStats.point -= point;
    } else {
      return res.status(400).json({ error: "Invalid action type" });
    }

    // Save the updated statistics
    await userStats.save();

    res.status(200).json({ success: true, newPoints: userStats.point });
  } catch (error) {
    console.error("Error managing points:", error);
    res.status(500).json({ error: "An error occurred while managing points" });
  }
});

app.get("/my/:userId/communities", async (req, res) => {
  try {
    const { userId } = req.params;

    // Find all communities that the user follows
    const communities = await Community.findAll({
      include: [
        {
          model: FollowCommunity,
          as: "Followers",
          where: { follower: userId },
        },
      ],
    });

    res.status(200).json({ communities });
  } catch (error) {
    console.error("Error fetching communities:", error);
    res
      .status(500)
      .json({ error: "An error occurred while fetching communities." });
  }
});

app.get("/users/:userId/following", async (req, res) => {
  try {
    const { userId } = req.params;

    // Find users that the specified user follows using the FollowUser model
    const followingTrackers = await FollowUser.findAll({
      where: { follower: userId },
      include: [
        {
          model: User,
          as: "FollowedUser",
        },
      ],
    });

    // Extract and return the list of followed users
    const followedUsers = followingTrackers.map(
      (tracker) => tracker.FollowedUser
    );
    res.status(200).json(followedUsers);
  } catch (error) {
    console.error("Error fetching following users:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Fetch users who follow a particular user
app.get("/users/:userId/followers", async (req, res) => {
  try {
    const { userId } = req.params;

    // Find users who follow the specified user using the FollowUser model
    const followerTrackers = await FollowUser.findAll({
      where: { followed: userId },
      include: [
        {
          model: User,
          as: "FollowerUser",
        },
      ],
    });

    // Extract and return the list of followers
    const followers = followerTrackers.map((tracker) => tracker.FollowerUser);
    res.status(200).json(followers);
  } catch (error) {
    console.error("Error fetching followers:", error);
    res.status(500).json({ message: "Server error" });
  }
});

app.get("/users/contacts/:userId", async (req, res) => {
  try {
    const { userId } = req.params;

    // Fetch messages where userId is either sender or receiver
    const messages = await Message.findAll({
      where: {
        [Op.or]: [{ senderId: userId }, { receiverId: userId }],
      },
      attributes: ["senderId", "receiverId"],
      raw: true,
    });

    // Extract unique user IDs from the messages
    const userIds = new Set();
    messages.forEach((message) => {
      if (message.senderId !== userId) {
        userIds.add(message.senderId);
      }
      if (message.receiverId !== userId) {
        userIds.add(message.receiverId);
      }
    });

    // Convert Set to array
    const userIdArray = Array.from(userIds);

    // Fetch user details for these user IDs
    const users = await User.findAll({
      where: {
        id: userIdArray,
      },
    });

    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "An error occurred while fetching users." });
  }
});

app.get("/user-statistics", async (req, res) => {
  try {
    const userStatistics = await UserStatistics.findAll({
      include: [{ model: User }],
      order: [["point", "DESC"]],
    });

    res.json(userStatistics);
  } catch (error) {
    console.error("Error fetching user statistics:", error);
    res.status(500).json({ error: "Failed to fetch user statistics" });
  }
});

app.post("/delete-social", async (req, res) => {
  const { id, action, tableType, content } = req.body;

  try {
    // Simulate deleting or updating an entry based on action and tableType
    if (tableType === "post") {
      if (action === "delete") {
        Post.destroy({ where: { id } });
        res.status(200).json({ message: "Post deleted successfully!" });
      } else {
        // Handle other actions like updating, archiving, etc.
        console.log(`Performing action ${action} on post with ID: ${id}`);
        res
          .status(200)
          .json({ message: `Action ${action} performed successfully!` });
      }
    } else if (tableType == "community") {
      if (action === "delete") {
        Community.destroy({ where: { id } });
        res.status(200).json({ message: "Community deleted successfully!" });
      } else {
        // Handle other actions like updating, archiving, etc.
        console.log(`Performing action ${action} on post with ID: ${id}`);
        res
          .status(200)
          .json({ message: `Action ${action} performed successfully!` });
      }
    } else {
      res.status(400).json({ error: "Invalid table type." });
    }
  } catch (error) {
    console.error("Error handling the request:", error);
    res
      .status(500)
      .json({ error: "An error occurred while processing the request." });
  }
});
app.get("/referrals/:userId", async (req, res) => {
  try {
    // Get the userId from the request params
    const userId = req.params.userId;

    // Find the user by ID
    const referringUser = await User.findOne({
      where: { id: userId },
    });

    if (!referringUser) {
      return res.status(404).send({ error: "User not found." });
    }

    // Get the list of users referred by the current user
    const referrals = await Referral.findAll({
      where: { referredBy: userId },
      include: [
        {
          model: User,
          as: "ReferredUser", // Using the alias defined in the model associations
        },
      ],
    });

    // Send the promo code and the referred users
    res.status(200).send({
      promoCode: referringUser.promoCode, // This uses the promoCode getter method
      referredUsers: referrals,
    });
  } catch (error) {
    console.error("Error fetching referrals:", error);
    res
      .status(500)
      .send({ error: "An error occurred while fetching referrals." });
  }
});
// Route to fetch all bank records
app.get("/banks", async (req, res) => {
  try {
    const banks = await Bank.findAll(); // Fetch all rows from the Banks table
    return res.status(200).json(banks); // Return the results as JSON
  } catch (error) {
    console.error("Error fetching banks:", error);
    return res.status(500).json({ error: "Something went wrong!" });
  }
});

app.get("/guide-video", async (req, res) => {
  try {
    const guideVideos = await GuideVideo.findAll();
    res.status(200).json(guideVideos);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching guide videos." });
  }
});

const PORT = process.env.PORT || 3000;
db.sequelize.sync().then(() => {
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running on port ${PORT}`);
  });
});
