module.exports = (sequelize, DataTypes) => {
  const Message = sequelize.define("Message", {
    senderId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    receiverId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    content: {
      type: DataTypes.TEXT, // Use TEXT to accommodate longer messages
      allowNull: false,
    },
    isRead: {
      type: DataTypes.BOOLEAN, // Change the data type to BOOLEAN
      allowNull: false,
      defaultValue: false, // You can also set a default value
    },
    timestamp: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW, // Automatically set to the current date and time
    },
  });
  Message.associate = function (models) {
    // A Message belongs to a sender (User)
    Message.belongsTo(models.User, {
      foreignKey: "senderId",
      as: "Sender",
    });

    // A Message belongs to a receiver (User)
    Message.belongsTo(models.User, {
      foreignKey: "receiverId",
      as: "Receiver",
    });
  };

  return Message;
};
