const express = require("express");
const router = express.Router();
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const multer = require("multer");
const { Payment, User, UserStatistics } = require("../models");
const { where } = require("sequelize");
router.use(cors());
router.use(express.json());

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = "uploads/payment";
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir);
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

router.use(express.urlencoded({ extended: true }));

// Route to handle payment form submission
router.post(
  "/submit-payment",
  upload.single("receiptImage"),
  async (req, res) => {
    const { transactionNumber, userId, bankName } = req.body;
    const receiptImage = req.file;
    console.log("payment accessed");
    var newData = {};
    if (!transactionNumber && !receiptImage) {
      return res.status(400).json({
        error: "Either transaction number or receipt image is required.",
      });
    }

    if (transactionNumber) {
      console.log(`Transaction Number: ${transactionNumber}`);
      newData.transactionNumber = transactionNumber;
    }

    if (receiptImage) {
      console.log(`Receipt Image Path: ${receiptImage.path}`);
      newData.receiptImage = receiptImage.path;
    }
    newData.userId = userId;
    newData.bankName = bankName;
    await Payment.destroy({ where: { userId } });
    await Payment.create(newData);
    req.app.get("io").emit("paymentNotice", newData);
    res.status(200).json({ message: "Form submitted successfully." });
  }
);
router.get("/payment-requests", async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;

    const offset = (page - 1) * limit;

    const { rows: payments, count: totalPayments } =
      await Payment.findAndCountAll({
        where: { status: ["unapproved", "declined"] },
        include: {
          model: User,
          include: {
            model: UserStatistics,
          },
        },
        offset,
        limit: Number(limit),
      });

    res.json({
      payments,
      totalPayments,
      totalPages: Math.ceil(totalPayments / limit),
      currentPage: Number(page),
    });
  } catch (error) {
    console.error("Error fetching payments:", error);
    res.status(500).json({ error: "Server Error" });
  }
});
router.post("/approval", async (req, res) => {
  try {
    const { userId, action } = req.body;
    console.log(userId, action);
    if (action === "approve") {
      await Payment.update(
        {
          status: action,
        },
        { where: { userId } }
      );
      await UserStatistics.update(
        {
          paymentStatus: "paid",
        },
        { where: { userId } }
      );

      res.status(200).json("approval succeeded");
    } else {
      await Payment.update(
        {
          status: "declined",
        },
        { where: { userId } }
      );

      res.status(200).json("Request Declined");
    }
  } catch (error) {
    console.error("Error approving payment:", error);
    res.status(500).json({ error: "Server Error" });
  }
});

router.get("/status/:userId", async (req, res) => {
  const userId = req.params.userId;
  const payment = await UserStatistics.findOne({
    where: { userId: userId, paymentStatus: "paid" },
  });
  console.log(userId);
  if (payment) {
    res
      .status(200)
      .json({ message: "Congratulations! Your Payment Has Been Approved!" });
  } else {
    const payment = await Payment.findOne({
      where: { userId: userId, status: "declined" },
    });
    if (payment) {
      res.status(406).json({
        message:
          "Your Request has been declined.Please call us for more information",
      });
    } else {
      res.status(403).json({
        message:
          "Your Payment Is Under Review! We Will Get Back To You Shortly.",
      });
    }
  }
});

module.exports = router;
